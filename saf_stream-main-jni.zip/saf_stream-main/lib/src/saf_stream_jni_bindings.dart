// PLACEHOLDER -- not the real generated bindings.
//
// This file exists purely so the project *compiles* before jnigen has ever
// been run. jnigen's `add_gradle_deps` needs a prior successful
// Gradle/Android build to source its classpath from, but our Dart code
// already imports this file -- so without a placeholder, nothing could
// build even once, and jnigen would never get the successful build it
// needs.
//
// You do NOT need to run jnigen locally or have Android Studio/SDK
// installed. `build_bench_apks.sh` (and the GitHub Actions workflow that
// calls it) does the whole bootstrap automatically on the CI runner, which
// already has a JDK + Android SDK preinstalled:
//   1. builds once against this placeholder (warms Gradle's dependency
//      cache -- compiles fine, these methods are just never called yet)
//   2. runs `dart run jnigen --config jnigen.yaml`, which overwrites this
//      file with the real generated bindings
//   3. rebuilds for real against the generated bindings
//
// If you DO want to generate bindings locally instead (e.g. to develop
// against them in an IDE with real autocomplete), the same three steps
// work by hand: `flutter build apk` once, `dart run jnigen --config
// jnigen.yaml`, then rebuild.
library;

import 'dart:typed_data';

class SafStreamJniBindings {
  SafStreamJniBindings._();

  static Never _notGenerated(String member) {
    throw UnimplementedError(
      'saf_stream_jni_bindings.dart is still the placeholder -- run '
      '`dart run jnigen --config jnigen.yaml` (see the comment at the top '
      'of this file) to generate the real bindings before calling '
      '$member.',
    );
  }

  static Uint8List readChunk(String session, int length) =>
      _notGenerated('readChunk');

  static int skipInput(String session, int count) => _notGenerated('skipInput');

  static void closeInputStream(String session) => _notGenerated('closeInputStream');

  static void writeChunk(String session, Uint8List data) =>
      _notGenerated('writeChunk');

  static void closeOutputStream(String session) => _notGenerated('closeOutputStream');

  static Uint8List readFileBytes(String uri, int start, int count) =>
      _notGenerated('readFileBytes');
}
