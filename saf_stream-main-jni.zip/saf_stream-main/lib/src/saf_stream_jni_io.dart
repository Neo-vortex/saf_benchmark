import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:jni/jni.dart';

/// Drives the byte-heavy read/write paths straight through JNI, bypassing
/// MethodChannel/EventChannel entirely. `session` here is the same session
/// id already used by [MethodChannelSafStream] (created before calling the
/// `readFileStream` / `startWriteStream` / `startReadCustomFileStream`
/// MethodChannel methods, which only do the one-time setup: resolving the
/// DocumentFile, opening the stream, and registering it under that session
/// on the Kotlin side). Everything that repeats -- one call per chunk --
/// happens here instead, with no BinaryMessenger codec and no forced
/// platform-thread hop.
///
/// This uses package:jni's low-level, no-codegen API (`JClass.forName` +
/// `staticMethodId` + `.call(...)`), matching the pattern shown in
/// package:jni's own example (pub.dev/packages/jni/example):
///
/// ```dart
/// final math = JClass.forName("java/lang/Math");
/// final random = math.staticMethodId("random", "()D").call(math, jdouble.type, []);
/// ```
///
/// jnigen (the codegen tool) is deliberately NOT used here: it needs
/// `android.content.Context` (etc.) resolvable via static source analysis
/// at codegen time, which jnigen's own docs say isn't reliably supported
/// ("core libraries (the android.** namespace) are not downloaded through
/// Gradle... we don't have an automatic mechanism for using these"). At
/// runtime, inside the actual running app, those classes are already
/// loaded by the JVM, so calling them reflectively avoids that problem
/// entirely.
///
/// Byte payloads are Base64-encoded strings rather than raw byte[]: String
/// <-> JString marshalling (`.toJString()` / `.toDartString()`) is directly
/// shown in package:jni's own example above; raw byte[] marshalling through
/// this low-level API is not, so this keeps every call on documented
/// ground rather than guessing. It costs some CPU for encode/decode, which
/// is still far cheaper than the MethodChannel round trip per chunk this
/// replaces.
class SafStreamJniIo {
  SafStreamJniIo._();

  static JClass? _cls;

  static JClass get _class =>
      _cls ??= JClass.forName('com/fluttercavalry/saf_stream/SafStreamJni');

  static Uint8List _readChunkB64(String session, int length) {
    final jSession = session.toJString();
    try {
      final jResult = _class
          .staticMethodId('readChunkB64', '(Ljava/lang/String;I)Ljava/lang/String;')
          .call(_class, JString.type, [jSession, length]);
      final b64 = jResult.toDartString(releaseOriginal: true);
      if (b64.isEmpty) return Uint8List(0);
      return base64Decode(b64);
    } finally {
      jSession.release();
    }
  }

  /// Pull-based chunked read. Replaces the old EventChannel-pushed stream:
  /// Dart now asks for chunks in a loop instead of native code pushing
  /// them, which also means reads can be paused/cancelled without extra
  /// plumbing (just stop calling readChunk).
  static Stream<Uint8List> readStream(
    String session, {
    required int bufferSize,
  }) {
    late StreamController<Uint8List> controller;
    var cancelled = false;

    Future<void> pump() async {
      try {
        while (!cancelled) {
          final chunk = _readChunkB64(session, bufferSize);
          if (chunk.isEmpty) break;
          controller.add(chunk);
        }
      } catch (err, st) {
        if (!cancelled) controller.addError(err, st);
      } finally {
        if (!cancelled) await controller.close();
        endRead(session);
      }
    }

    controller = StreamController<Uint8List>(
      onListen: () {
        unawaited(pump());
      },
      onCancel: () {
        cancelled = true;
      },
    );
    return controller.stream;
  }

  /// Single chunk pull, used by the `startReadCustomFileStream` /
  /// `readCustomFileStreamChunk` family. Returns null at EOF.
  static Uint8List? readCustomChunk(String session, int bufferSize) {
    final chunk = _readChunkB64(session, bufferSize);
    return chunk.isEmpty ? null : chunk;
  }

  static int skip(String session, int count) {
    final jSession = session.toJString();
    try {
      return _class
          .staticMethodId('skipInput', '(Ljava/lang/String;J)J')
          .call(_class, jlong.type, [jSession, count]);
    } finally {
      jSession.release();
    }
  }

  static void endRead(String session) {
    final jSession = session.toJString();
    try {
      _class
          .staticMethodId('closeInputStream', '(Ljava/lang/String;)V')
          .call(_class, jvoid.type, [jSession]);
    } finally {
      jSession.release();
    }
  }

  static void writeChunk(String session, Uint8List data) {
    final jSession = session.toJString();
    final jData = base64Encode(data).toJString();
    try {
      _class
          .staticMethodId('writeChunkB64', '(Ljava/lang/String;Ljava/lang/String;)V')
          .call(_class, jvoid.type, [jSession, jData]);
    } finally {
      jSession.release();
      jData.release();
    }
  }

  static void endWrite(String session) {
    final jSession = session.toJString();
    try {
      _class
          .staticMethodId('closeOutputStream', '(Ljava/lang/String;)V')
          .call(_class, jvoid.type, [jSession]);
    } finally {
      jSession.release();
    }
  }

  static Uint8List readFileBytes(String uri, {required int start, required int count}) {
    final jUri = uri.toJString();
    try {
      final jResult = _class
          .staticMethodId('readFileBytesB64', '(Ljava/lang/String;JI)Ljava/lang/String;')
          .call(_class, JString.type, [jUri, start, count]);
      final b64 = jResult.toDartString(releaseOriginal: true);
      if (b64.isEmpty) return Uint8List(0);
      return base64Decode(b64);
    } finally {
      jUri.release();
    }
  }
}
