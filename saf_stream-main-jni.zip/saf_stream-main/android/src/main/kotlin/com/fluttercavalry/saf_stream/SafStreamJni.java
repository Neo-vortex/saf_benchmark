package com.fluttercavalry.saf_stream;

import android.content.Context;
import androidx.core.net.Uri;
import androidx.documentfile.provider.DocumentFile;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * JNI-callable bridge used for the hot, byte-heavy read/write paths.
 *
 * This is plain Java (not Kotlin) specifically so that jnigen's source-based
 * summarizer can parse it directly (jnigen's support for raw Kotlin source is
 * limited/unreliable; Kotlin would need to be pre-compiled to bytecode and
 * summarized via the "asm" backend + classpath instead, which is a much more
 * fragile setup for a small bridge class like this one).
 *
 * Why this exists at all: MethodChannel/EventChannel round-trips go through
 * Flutter's binary messenger -- every call is encoded with
 * StandardMessageCodec, posted to the platform thread, decoded natively, and
 * the result posted back the same way. saf_stream's streaming APIs made one
 * such round-trip *per chunk*. package:jni lets Dart call plain JVM methods
 * directly (like cronet_http does), with no BinaryMessenger, no codec, and no
 * forced platform-thread hop.
 *
 * All methods are `public static` with JNI-simple signatures (String, long,
 * int, byte[]) so jnigen can generate straightforward Dart bindings.
 */
public final class SafStreamJni {
    private SafStreamJni() {}

    private static volatile Context appContext;

    private static final Map<String, InputStream> inputStreams = new ConcurrentHashMap<>();
    private static final Map<String, OutputStream> outputStreams = new ConcurrentHashMap<>();

    public static void setAppContext(Context context) {
        appContext = context;
    }

    private static Context ctx() {
        if (appContext == null) {
            throw new IllegalStateException("SafStreamJni.appContext has not been initialized");
        }
        return appContext;
    }

    // -----------------------------------------------------------------
    // Reading
    // -----------------------------------------------------------------

    /**
     * Registers an already-opened stream under {@code session}. Called once
     * per stream from Kotlin plugin code (triggered by the existing
     * MethodChannel `readFileStream` / `startReadCustomFileStream` calls),
     * not from Dart directly.
     */
    public static void registerInputStream(String session, InputStream stream) {
        inputStreams.put(session, stream);
    }

    /**
     * Reads up to {@code length} bytes from the stream registered under
     * {@code session}. Returns an empty array at EOF. Called directly from
     * Dart via JNI, in a loop -- this is the hot path.
     */
    public static byte[] readChunk(String session, int length) throws IOException {
        InputStream stream = inputStreams.get(session);
        if (stream == null) {
            throw new IOException("Read stream not found for session: " + session);
        }
        byte[] buffer = new byte[length];
        int n = stream.read(buffer, 0, length);
        if (n <= 0) {
            return new byte[0];
        }
        if (n == length) {
            return buffer;
        }
        byte[] result = new byte[n];
        System.arraycopy(buffer, 0, result, 0, n);
        return result;
    }

    /** Skips {@code count} bytes on the stream registered under {@code session}. */
    public static long skipInput(String session, long count) throws IOException {
        InputStream stream = inputStreams.get(session);
        if (stream == null) {
            throw new IOException("Read stream not found for session: " + session);
        }
        return stream.skip(count);
    }

    /** Closes and unregisters the input stream for {@code session}. */
    public static void closeInputStream(String session) throws IOException {
        InputStream stream = inputStreams.remove(session);
        if (stream != null) {
            stream.close();
        }
    }

    /**
     * One-shot read (backs `readFileBytes`). Not chunked, so a plain JNI call
     * (no session bookkeeping) is enough; it still skips the MethodChannel
     * codec round trip for the returned byte array.
     */
    public static byte[] readFileBytes(String uriStr, long start, int count) throws IOException {
        InputStream stream = ctx().getContentResolver().openInputStream(Uri.parse(uriStr));
        if (stream == null) {
            throw new IOException("Failed to open input stream for " + uriStr);
        }
        try {
            if (start > 0) {
                stream.skip(start);
            }
            if (count > 0) {
                byte[] buffer = new byte[count];
                int n = stream.read(buffer, 0, count);
                if (n <= 0) {
                    return new byte[0];
                }
                if (n == count) {
                    return buffer;
                }
                byte[] result = new byte[n];
                System.arraycopy(buffer, 0, result, 0, n);
                return result;
            } else {
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = stream.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
                return out.toByteArray();
            }
        } finally {
            stream.close();
        }
    }

    // -----------------------------------------------------------------
    // Writing
    // -----------------------------------------------------------------

    /**
     * Registers an already-opened stream under {@code session}. Called once
     * per stream from Kotlin plugin code (triggered by the existing
     * MethodChannel `startWriteStream` call), not from Dart directly.
     */
    public static void registerOutputStream(String session, OutputStream stream) {
        outputStreams.put(session, stream);
    }

    /**
     * Writes {@code data} to the stream registered under {@code session}.
     * Called directly from Dart via JNI, once per chunk -- this is the hot
     * path that used to be a `writeChunk` MethodChannel call per chunk.
     */
    public static void writeChunk(String session, byte[] data) throws IOException {
        OutputStream stream = outputStreams.get(session);
        if (stream == null) {
            throw new IOException("Write stream not found for session: " + session);
        }
        stream.write(data);
    }

    /** Flushes, closes and unregisters the output stream for {@code session}. */
    public static void closeOutputStream(String session) throws IOException {
        OutputStream stream = outputStreams.remove(session);
        if (stream != null) {
            stream.flush();
            stream.close();
        }
    }

    /** Used for cleanup if a session is abandoned (e.g. app killed mid-stream). */
    public static void reset() {
        for (InputStream s : inputStreams.values()) {
            try { s.close(); } catch (IOException ignored) {}
        }
        for (OutputStream s : outputStreams.values()) {
            try { s.close(); } catch (IOException ignored) {}
        }
        inputStreams.clear();
        outputStreams.clear();
    }
}
