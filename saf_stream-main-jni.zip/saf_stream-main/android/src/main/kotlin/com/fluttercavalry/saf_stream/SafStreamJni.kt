package com.fluttercavalry.saf_stream

import android.content.Context
import android.util.Base64
import androidx.annotation.Keep
import androidx.core.net.toUri
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * JNI-callable bridge used for the hot, byte-heavy read/write paths.
 *
 * Called directly from Dart at runtime via package:jni's low-level API
 * (`JClass.forName` + `staticMethodId` + `.call(...)`), NOT via jnigen
 * codegen. That's a deliberate choice: jnigen's static source analysis
 * needs `android.content.Context` etc. resolvable at *codegen* time, which
 * requires either a working `android_sdk_config` Gradle-stub classpath
 * (unreliable per jnigen's own docs -- "core libraries (the android.**
 * namespace) are not downloaded through Gradle... we don't have an
 * automatic mechanism for using these") or manually unpacking Android SDK
 * stub sources. At *runtime*, inside the actual running app, the JVM
 * already has these classes loaded -- there's nothing to resolve, so
 * calling reflectively at runtime sidesteps that whole problem.
 *
 * Byte payloads (readChunk/writeChunk/readFileBytes) are Base64-encoded
 * Strings rather than raw byte[]. This is deliberate too: String<->JString
 * marshalling is directly documented/exampled by package:jni
 * (`'text'.toJString()` / `jstring.toDartString()`); raw byte[] argument/
 * return marshalling for the low-level reflective API is not, so this
 * avoids guessing at an unconfirmed part of the API. It costs some CPU for
 * the encode/decode, but that's still far cheaper than a MethodChannel
 * round trip per chunk, which is the actual problem being solved here.
 *
 * All methods are `@JvmStatic` on a Kotlin `object` with JNI-simple
 * signatures (String, Long, Int) so they're trivial to look up by name +
 * signature from Dart.
 */
@Keep
object SafStreamJni {
    @JvmStatic
    @Volatile
    var appContext: Context? = null

    private val inputStreams = ConcurrentHashMap<String, InputStream>()
    private val outputStreams = ConcurrentHashMap<String, OutputStream>()

    private fun ctx(): Context =
        appContext ?: throw IllegalStateException("SafStreamJni.appContext has not been initialized")

    // ---------------------------------------------------------------------
    // Reading
    // ---------------------------------------------------------------------

    /**
     * Registers an already-opened [stream] under [session]. Called once per
     * stream from Kotlin plugin code (triggered by the existing
     * MethodChannel `readFileStream` / `startReadCustomFileStream` calls),
     * not from Dart directly.
     */
    fun registerInputStream(
        session: String,
        stream: InputStream,
    ) {
        inputStreams[session] = stream
    }

    /**
     * Reads up to [length] bytes from the stream registered under
     * [session], Base64-encoded. Returns an empty string at EOF. Called
     * directly from Dart via JNI, in a loop -- this is the hot path.
     */
    @JvmStatic
    fun readChunkB64(
        session: String,
        length: Int,
    ): String {
        val stream = inputStreams[session] ?: throw Exception("Read stream not found for session: $session")
        val buffer = ByteArray(length)
        val n = stream.read(buffer, 0, length)
        if (n <= 0) return ""
        val bytes = if (n == length) buffer else buffer.copyOf(n)
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    /** Skips [count] bytes on the stream registered under [session]. */
    @JvmStatic
    fun skipInput(
        session: String,
        count: Long,
    ): Long {
        val stream = inputStreams[session] ?: throw Exception("Read stream not found for session: $session")
        return stream.skip(count)
    }

    /** Closes and unregisters the input stream for [session]. */
    @JvmStatic
    fun closeInputStream(session: String) {
        inputStreams.remove(session)?.close()
    }

    /**
     * One-shot read (backs `readFileBytes`), Base64-encoded. Not chunked,
     * so a plain JNI call (no session bookkeeping) is enough; still skips
     * the MethodChannel codec round trip for what can be a very large
     * payload.
     */
    @JvmStatic
    fun readFileBytesB64(
        uriStr: String,
        start: Long,
        count: Int,
    ): String {
        val stream =
            ctx().contentResolver.openInputStream(uriStr.toUri())
                ?: throw Exception("Failed to open input stream for $uriStr")
        stream.use {
            if (start > 0) {
                it.skip(start)
            }
            val bytes =
                if (count > 0) {
                    val buffer = ByteArray(count)
                    val n = it.read(buffer, 0, count)
                    if (n <= 0) ByteArray(0) else buffer.copyOf(n)
                } else {
                    it.buffered().readBytes()
                }
            return Base64.encodeToString(bytes, Base64.NO_WRAP)
        }
    }

    // ---------------------------------------------------------------------
    // Writing
    // ---------------------------------------------------------------------

    /**
     * Registers an already-opened [stream] under [session]. Called once per
     * stream from Kotlin plugin code (triggered by the existing
     * MethodChannel `startWriteStream` call), not from Dart directly.
     */
    fun registerOutputStream(
        session: String,
        stream: OutputStream,
    ) {
        outputStreams[session] = stream
    }

    /**
     * Writes Base64-encoded [base64Data] to the stream registered under
     * [session]. Called directly from Dart via JNI, once per chunk -- this
     * is the hot path that used to be a `writeChunk` MethodChannel call per
     * chunk.
     */
    @JvmStatic
    fun writeChunkB64(
        session: String,
        base64Data: String,
    ) {
        val stream = outputStreams[session] ?: throw Exception("Write stream not found for session: $session")
        stream.write(Base64.decode(base64Data, Base64.NO_WRAP))
    }

    /** Flushes, closes and unregisters the output stream for [session]. */
    @JvmStatic
    fun closeOutputStream(session: String) {
        outputStreams.remove(session)?.let {
            it.flush()
            it.close()
        }
    }

    /** Used for cleanup if a session is abandoned (e.g. app killed mid-stream). */
    fun reset() {
        inputStreams.values.forEach { runCatching { it.close() } }
        outputStreams.values.forEach { runCatching { it.close() } }
        inputStreams.clear()
        outputStreams.clear()
    }
}
