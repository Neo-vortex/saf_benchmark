package com.fluttercavalry.saf_stream

import android.content.Context
import androidx.core.net.toUri
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * JNI-callable bridge used for the hot, byte-heavy read/write paths.
 *
 * Why this exists:
 * MethodChannel (and EventChannel) round-trips go through Flutter's binary
 * messenger: every call is encoded with StandardMessageCodec, posted to the
 * platform thread, decoded on the native side, and the result is posted back
 * the same way. For a handful of calls this is fine, but `saf_stream`'s
 * streaming APIs make one such round-trip *per chunk*, so a large file can
 * mean thousands of channel messages, each paying that serialization +
 * thread-hop cost.
 *
 * package:jni lets Dart call plain JVM methods directly (like cronet_http
 * does), with no BinaryMessenger, no codec, and no forced platform-thread
 * hop. We keep MethodChannel for one-shot / metadata calls (resolving a
 * DocumentFile, creating a new file, returning its uri/name, etc. -- things
 * that happen once per operation) and use JNI only for the parts that repeat:
 * reading/writing chunks and skipping bytes.
 *
 * All methods here are `@JvmStatic` on a Kotlin `object` with JNI-simple
 * signatures (String, Long, Int, Boolean, ByteArray) so they can be resolved
 * by name + signature from Dart via `JClass.forName` without requiring a
 * jnigen code-generation step.
 */
object SafStreamJni {
    @JvmStatic
    @Volatile
    var appContext: Context? = null

    private val inputStreams = ConcurrentHashMap<String, InputStream>()
    private val outputStreams = ConcurrentHashMap<String, OutputStream>()

    private fun ctx(): Context =
        appContext ?: throw IllegalStateException("SafStreamJni.appContext has not been initialized")

    // ---------------------------------------------------------------------
    // Reading
    // ---------------------------------------------------------------------

    /**
     * Opens an input stream for [uriStr] and registers it under [session].
     * Called once per stream from Kotlin (triggered by the existing
     * MethodChannel `readFileStream` / `startReadCustomFileStream` calls),
     * not from Dart directly.
     */
    fun registerInputStream(
        session: String,
        stream: InputStream,
    ) {
        inputStreams[session] = stream
    }

    /**
     * Reads up to [length] bytes from the stream registered under [session].
     * Returns an empty [ByteArray] at EOF. Called directly from Dart via JNI,
     * in a loop, for every chunk -- this is the hot path.
     */
    @JvmStatic
    fun readChunk(
        session: String,
        length: Int,
    ): ByteArray {
        val stream = inputStreams[session] ?: throw Exception("Read stream not found for session: $session")
        val buffer = ByteArray(length)
        val n = stream.read(buffer, 0, length)
        if (n <= 0) return ByteArray(0)
        return if (n == length) buffer else buffer.copyOf(n)
    }

    /** Skips [count] bytes on the stream registered under [session]. */
    @JvmStatic
    fun skipInput(
        session: String,
        count: Long,
    ): Long {
        val stream = inputStreams[session] ?: throw Exception("Read stream not found for session: $session")
        return stream.skip(count)
    }

    /** Closes and unregisters the input stream for [session]. */
    @JvmStatic
    fun closeInputStream(session: String) {
        inputStreams.remove(session)?.close()
    }

    /**
     * One-shot read (backs `readFileBytes`). Not chunked, so a plain JNI call
     * (no session bookkeeping) is enough; it still skips the MethodChannel
     * codec round trip for the returned byte array.
     */
    @JvmStatic
    fun readFileBytes(
        uriStr: String,
        start: Long,
        count: Int,
    ): ByteArray {
        val stream =
            ctx().contentResolver.openInputStream(uriStr.toUri())
                ?: throw Exception("Failed to open input stream for $uriStr")
        stream.use {
            if (start > 0) {
                it.skip(start)
            }
            return if (count > 0) {
                val buffer = ByteArray(count)
                val n = it.read(buffer, 0, count)
                if (n <= 0) ByteArray(0) else buffer.copyOf(n)
            } else {
                it.buffered().readBytes()
            }
        }
    }

    // ---------------------------------------------------------------------
    // Writing
    // ---------------------------------------------------------------------

    /**
     * Registers an already-opened [stream] under [session]. Called once per
     * stream from Kotlin (triggered by the existing MethodChannel
     * `startWriteStream` call), not from Dart directly.
     */
    fun registerOutputStream(
        session: String,
        stream: OutputStream,
    ) {
        outputStreams[session] = stream
    }

    /**
     * Writes [data] to the stream registered under [session]. Called
     * directly from Dart via JNI, once per chunk -- this is the hot path
     * that used to be a `writeChunk` MethodChannel call per chunk.
     */
    @JvmStatic
    fun writeChunk(
        session: String,
        data: ByteArray,
    ) {
        val stream = outputStreams[session] ?: throw Exception("Write stream not found for session: $session")
        stream.write(data)
    }

    /** Flushes, closes and unregisters the output stream for [session]. */
    @JvmStatic
    fun closeOutputStream(session: String) {
        outputStreams.remove(session)?.let {
            it.flush()
            it.close()
        }
    }

    /** Used for cleanup if a session is abandoned (e.g. app killed mid-stream). */
    fun reset() {
        inputStreams.values.forEach { runCatching { it.close() } }
        outputStreams.values.forEach { runCatching { it.close() } }
        inputStreams.clear()
        outputStreams.clear()
    }
}
